<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mental Health Support Resources</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1 {
            color: #00bfa5;
            margin-bottom: 20px;
        }

        .resource-list {
            list-style-type: none;
            padding: 0;
        }

        .resource-list li {
            background-color: #fff;
            margin: 10px 0;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
        }

        .resource-list a {
            text-decoration: none;
            color: #00897b;
            font-weight: bold;
        }

        .appointment-btn {
            margin-top: 20px;
            padding: 12px 20px;
            border-radius: 5px;
            background-color: #00bfa5;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
            text-align: center;
            text-decoration: none;
        }

        .appointment-btn:hover {
            background-color: #00897b;
        }
    </style>
</head>
<body>
    <h1>Mental Health Support Resources</h1>
    <ul class="resource-list">
        <li>
            <h2>Understanding Anxiety and Depression</h2>
            <p>Explore this video that provides insights into the symptoms and management of anxiety and depression.</p>
            <a href="https://youtu.be/rIdzpsh99E0?si=sbitsyqMIw9_pBe1" target="_blank">Watch Video</a>
        </li>
        <li>
            <h2>Mindfulness Meditation for Beginners</h2>
            <p>Learn the basics of mindfulness meditation with this guided session.</p>
            <a href="https://youtu.be/U9YKY7fdwyg?si=bho9mrhp99mW5X3k" target="_blank">Watch Video</a>
        </li>
        <li>
            <h2>Mental Health Podcasts</h2>
            <p>Tune into podcasts focused on mental health and well-being.</p>
            <a href="https://open.spotify.com/playlist/77AOjGgwOTmcDiH15lARCh?si=ErD2hVdBS9en7K3pc6LOZg&pi=KHhSTq96RM21g" target="_blank">Listen to Podcast</a>
        </li>
    </ul>
    <a class="appointment-btn" href="book-appointment.php">Book an Appointment</a>
</body>
</html>

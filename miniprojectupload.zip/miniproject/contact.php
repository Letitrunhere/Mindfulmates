<!--  ************************* Contact Us Starts Here ************************** -->
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us Form</title>
    <style>
        /* Style for the Contact Us Form Section */
        #contact_us {
            padding: 60px 0;
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
        }

        #contact_us .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
        }

        #contact_us h2 {
            text-align: center;
            color: #00bfa5;
            margin-bottom: 40px;
            font-size: 32px;
            font-weight: bold;
        }

        /* Form Input Styling */
        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            font-size: 16px;
            color: #333;
            font-weight: bold;
            display: block;
            margin-bottom: 8px;
        }

        .form-control {
            width: 100%;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            color: #333;
            background-color: #fafafa;
            transition: all 0.3s ease;
            box-sizing: border-box;
        }

        .form-control:hover {
            border-color: #00bfa5;
        }

        .form-control:focus {
            outline: none;
            border-color: #00bfa5;
            box-shadow: 0 0 10px rgba(0, 191, 165, 0.2);
        }

        textarea.form-control {
            resize: none;
            height: 150px;
        }

        /* Submit Button Styling */
        .btn {
            background-color: #00bfa5;
            color: white;
            border: none;
            padding: 15px 20px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            border-radius: 6px;
            width: 100%;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 191, 165, 0.4);
        }

        .btn:hover {
            background-color: #009f89;
            box-shadow: 0 6px 25px rgba(0, 191, 165, 0.6);
        }

        .btn:focus {
            outline: none;
            box-shadow: 0 0 12px rgba(0, 191, 165, 0.6);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .form-group label {
                font-size: 14px;
            }

            #contact_us h2 {
                font-size: 28px;
            }

            .btn {
                font-size: 16px;
            }
        }

    </style>
</head>
<body>

<!-- ************************* Contact Us Section ************************** -->
<section id="contact_us" class="contact-us-single">
    <div class="container">
        <h2>Contact Form</h2>
        <form method="post">
            <div class="form-group">
                <label for="fullname">Enter Name:</label>
                <input type="text" id="fullname" name="fullname" placeholder="Enter Name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="emailid">Email Address:</label>
                <input type="email" id="emailid" name="emailid" placeholder="Enter Email Address" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="mobileno">Mobile Number:</label>
                <input type="tel" id="mobileno" name="mobileno" placeholder="Enter Mobile Number" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="description">Enter Message:</label>
                <textarea id="description" name="description" placeholder="Enter Your Message" class="form-control" required></textarea>
            </div>
            <div class="form-group">
                <button class="btn" type="submit" name="submit">Send Message</button>
            </div>
        </form>
    </div>
</section>

</body>
</html>

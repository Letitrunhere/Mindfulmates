<?php
// Step 1: Database connection details
$servername = "localhost";  // Server name (usually 'localhost')
$username = "root";         // Your MySQL username
$password = "";             // Your MySQL password
$dbname = "hms";  // The name of your database

// Step 2: Create the database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 3: Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collecting the data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $reason = $_POST['reason'];
    $concerns = $_POST['concerns'];
    $experience = $_POST['experience'];
    $symptoms = $_POST['symptoms'];
    $support = $_POST['support'];
    $other_info = $_POST['other_info'];

    // Step 4: Convert all text input to lowercase for easier keyword matching
    $reason_lower = strtolower($reason);
    $concerns_lower = strtolower($concerns);
    $symptoms_lower = strtolower($symptoms);

    // Define keywords and corresponding resources page
    $keyword_redirects = [
        'anxiety' => 'resources_anxiety.php',
        'depression' => 'resources_depression.php',
        'stress' => 'resources_stress.php',
        'postpartum' => 'resources_postpartum.php',
        // Add more keywords and resource pages as needed
    ];

    // Look for keywords in the form input
    $redirect_page = 'resources.php'; // Default resource page

    foreach ($keyword_redirects as $keyword => $page) {
        if (strpos($reason_lower, $keyword) !== false || 
            strpos($concerns_lower, $keyword) !== false || 
            strpos($symptoms_lower, $keyword) !== false) {
            $redirect_page = $page;
            break; // Redirect to the first matched keyword page
        }
    }

    // Step 5: Prepare an SQL query to insert the form data into the database
    $sql = "INSERT INTO intake_form (name, email, reason, concerns, experience, symptoms, support, other_info) 
            VALUES ('$name', '$email', '$reason', '$concerns', '$experience', '$symptoms', '$support', '$other_info')";

    // Step 6: Execute the query and check if the data was inserted successfully
    if ($conn->query($sql) === TRUE) {
        echo "<p style='color: green;'>Form submitted successfully!</p>";
        // Redirect to the determined resource page
        header("Location: " . $redirect_page);
        exit(); // Ensure no further code is executed after redirection
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Step 7: Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mental Health Support System - Intake Form</title>
   <style>
    body {
    font-family: 'Arial', sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    min-height: 100vh;
    padding-top: 20px;
}

.form-container {
    background-color: #fff;
    padding: 30px;
    border-radius: 10px; /* Smoother border radius */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1); /* Softer, more modern shadow */
    width: 100%;
    max-width: 600px;
    margin-top: 20px;
    transition: transform 0.3s ease; /* Add some transition effect */
}

.form-container:hover {
    transform: translateY(-5px); /* Slight hover effect */
}

h2 {
    text-align: center;
    margin-bottom: 24px; /* Slightly increased for breathing room */
    color: #00bfa5;
    font-size: 24px; /* Larger font for clarity */
    line-height: 1.4; /* Improved line spacing */
}

label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
    font-size: 14px;
    color: #333;
}

input[type="text"], input[type="email"], textarea, select {
    width: 100%;
    padding: 14px; /* Slightly increased padding for comfort */
    margin-bottom: 18px;
    border-radius: 6px; /* Smoother border */
    border: 1px solid #ccc;
    box-sizing: border-box;
    font-size: 16px;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

input[type="text"]:focus, input[type="email"]:focus, textarea:focus, select:focus {
    border-color: #00bfa5; /* Focus state for better accessibility */
    box-shadow: 0 0 5px rgba(0, 191, 165, 0.5); /* Focus shadow */
    outline: none;
}

textarea {
    height: 120px; /* Increased height for better usability */
}

input[type="submit"] {
    width: 100%;
    padding: 14px;
    border-radius: 6px;
    background-color: #00bfa5;
    color: white;
    border: none;
    cursor: pointer;
    font-size: 16px;
    font-weight: bold;
    transition: background-color 0.3s, transform 0.3s;
}

input[type="submit"]:hover {
    background-color: #00897b;
    transform: translateY(-2px); /* Add subtle hover effect */
}

@media (max-width: 768px) {
    .form-container {
        padding: 20px; /* Reduce padding on smaller screens */
    }

    h2 {
        font-size: 20px; /* Adjust heading size for smaller devices */
    }

    input[type="text"], input[type="email"], textarea, select {
        padding: 12px; /* Reduce padding slightly on small screens */
    }

    input[type="submit"] {
        padding: 12px;
        font-size: 15px; /* Adjust font size for buttons */
    }
}
</style>
</head>
<body>
    <div class="form-container">
        <h2>Intake Form</h2>
        <form action="" method="post">
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email Address:</label>
            <input type="email" id="email" name="email" required>

            <label for="reason">Reason for Seeking Support:</label>
            <textarea id="reason" name="reason" required></textarea>

            <label for="concerns">Current Mental Health Concerns:</label>
            <textarea id="concerns" name="concerns" required></textarea>

            <label for="experience">Previous Counseling or Therapy Experience:</label>
            <textarea id="experience" name="experience"></textarea>

            <label for="symptoms">Current Symptoms (e.g., anxiety, depression, etc.):</label>
            <textarea id="symptoms" name="symptoms" required></textarea>

            <label for="support">What kind of support are you looking for?</label>
            <select id="support" name="support" required>
                <option value="counseling">Counseling</option>
                <option value="therapy">Therapy</option>
                <option value="peer_support">Peer Support</option>
                <option value="self_help">Self-Help Resources</option>
            </select>

            <label for="other_info">Is there anything else we should know?</label>
            <textarea id="other_info" name="other_info"></textarea>

            <input type="submit" value="Submit">
        </form>
    </div>
</body>
</html>

<?php
session_start();
include('include/config.php');
include('include/checklogin.php');
check_login();

if (isset($_POST['submitJournal'])) {
    $userId = $_SESSION['id'];  // Logged-in user's ID
    $mood = $_POST['mood'];     // Mood value from form
    $activities = $_POST['activities'];  // Journal text from form
    $entryDate = date('Y-m-d');  // Current date

    // Insert into the database
    $query = mysqli_query($con, "INSERT INTO journals (user_id, mood, activities, entry_date) VALUES ('$userId', '$mood', '$activities', '$entryDate')");

    if ($query) {
        $_SESSION['msg'] = "Journal entry added successfully!";
    } else {
        $_SESSION['msg'] = "Error adding journal entry!";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Journal and Mood Tracking</title>
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <style>
        body {
            background-color: #f4f4f4;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .container {
            background-color: white;
            border-radius: 15px;
            padding: 40px;
            margin-top: 50px;
            max-width: 800px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        h2, h3 {
            color: #333;
            font-weight: 600;
        }

        h2 {
            margin-bottom: 20px;
            font-size: 28px;
        }

        h3 {
            margin-top: 40px;
            font-size: 24px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 10px;
            font-size: 16px;
        }

        /* Improved Mood Selection */
        .mood-selection {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 25px;
        }

        .mood-option {
            width: 18%;
            text-align: center;
            position: relative;
            transition: transform 0.3s ease, background-color 0.3s ease;
        }

        .mood-option input[type="radio"] {
            display: none;
        }

        .mood-option label {
            display: block;
            padding: 15px;
            border: 2px solid transparent;
            border-radius: 10px;
            cursor: pointer;
            transition: background-color 0.3s, border-color 0.3s, transform 0.2s ease-in-out;
        }

        .mood-option label:hover {
            transform: translateY(-5px);
        }

        .mood-option i {
            font-size: 30px;
        }

        .mood-option label span {
            display: block;
            margin-top: 8px;
            font-size: 14px;
            font-weight: bold;
        }

        /* Unique colors for each mood */
        .mood1 label {
            background-color: #ffe6e6;
        }

        .mood2 label {
            background-color: #ffcccc;
        }

        .mood3 label {
            background-color: #fff4cc;
        }

        .mood4 label {
            background-color: #ccffcc;
        }

        .mood5 label {
            background-color: #cceeff;
        }

        /* Apply active styles when selected */
        .mood-option input[type="radio"]:checked + label {
            border-color: #007bff;
            background-color: #007bff;
            color: white;
        }

        .mood-option input[type="radio"]:checked + label i {
            color: white;
        }

        /* Form Button */
        .btn-primary {
            background-color: #007bff;
            border: none;
            padding: 12px 25px;
            font-size: 16px;
            border-radius: 8px;
            transition: background-color 0.3s ease, transform 0.3s ease;
            display: inline-block;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }

        .btn-primary:active {
            background-color: #00408a;
        }

        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.05);
        }

        table th, table td {
            text-align: center;
            padding: 15px;
            border-bottom: 1px solid #dee2e6;
            font-size: 16px;
        }

        table th {
            background-color: #007bff;
            color: white;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .mood-selection {
                flex-wrap: wrap;
                gap: 10px;
            }

            .mood-option {
                width: 48%;
                margin-bottom: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Journal and Mood Tracking</h2>

        <!-- Journal Submission Form -->
        <form method="POST">
            <div class="form-group">
                <label for="mood">Mood:</label>
                <div class="mood-selection">
                    <div class="mood-option mood1">
                        <input type="radio" id="mood1" name="mood" value="1">
                        <label for="mood1">
                            <i class="fa fa-frown-o"></i>
                            <span>Very Sad</span>
                        </label>
                    </div>
                    <div class="mood-option mood2">
                        <input type="radio" id="mood2" name="mood" value="2">
                        <label for="mood2">
                            <i class="fa fa-meh-o"></i>
                            <span>Sad</span>
                        </label>
                    </div>
                    <div class="mood-option mood3">
                        <input type="radio" id="mood3" name="mood" value="3">
                        <label for="mood3">
                            <i class="fa fa-meh-o"></i>
                            <span>Neutral</span>
                        </label>
                    </div>
                    <div class="mood-option mood4">
                        <input type="radio" id="mood4" name="mood" value="4">
                        <label for="mood4">
                            <i class="fa fa-smile-o"></i>
                            <span>Happy</span>
                        </label>
                    </div>
                    <div class="mood-option mood5">
                        <input type="radio" id="mood5" name="mood" value="5">
                        <label for="mood5">
                            <i class="fa fa-smile-o"></i>
                            <span>Very Happy</span>
                        </label>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label for="activities">Journal Entry:</label>
                <textarea class="form-control" id="activities" name="activities" rows="4" required></textarea>
            </div>

            <button type="submit" name="submitJournal" class="btn btn-primary">Submit Journal</button>
        </form>

        <!-- Journal History -->
        <h3 class="mt-5">Journal History</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Mood</th>
                    <th>Activities</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $userId = $_SESSION['id'];
            $historyQuery = mysqli_query($con, "SELECT * FROM journals WHERE user_id='$userId' ORDER BY entry_date DESC");
            if (mysqli_num_rows($historyQuery) > 0) {
                while ($row = mysqli_fetch_array($historyQuery)) {
                    echo "<tr>";
                    echo "<td>" . $row['entry_date'] . "</td>";
                    echo "<td>";
                    switch ($row['mood']) {
                        case 1: echo "<i class='fa fa-frown-o' style='font-size: 24px;'></i> Very Sad"; break;
                        case 2: echo "<i class='fa fa-meh-o' style='font-size: 24px;'></i> Sad"; break;
                        case 3: echo "<i class='fa fa-meh-o' style='font-size: 24px;'></i> Neutral"; break;
                        case 4: echo "<i class='fa fa-smile-o' style='font-size: 24px;'></i> Happy"; break;
                        case 5: echo "<i class='fa fa-smile-o' style='font-size: 24px;'></i> Very Happy"; break;
                    }
                    echo "</td>";
                    echo "<td>" . $row['activities'] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No journal entries found.</td></tr>";
            }
            ?>
            </tbody>
        </table>
    </div>
</body>
</html>

 <!--  ************************* Feedback Form Starts Here ************************** -->
 <?php
// Database connection details
$host = "localhost";  // Your database host
$dbname = "hms";  // Your database name
$username = "root";  // Your MySQL username
$password = "";  // Your MySQL password

// Create a connection to the database
$conn = new mysqli($host, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start the session
session_start();

// Check if the form is submitted
if (isset($_POST['submitFeedback'])) {
    // Get form data and escape to prevent SQL injection
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $rating = $conn->real_escape_string($_POST['rating']);
    $comments = $conn->real_escape_string($_POST['comments']);

    // Insert data into tblfeedback table
    $sql = "INSERT INTO tblfeedback (name, email, rating, comments, submission_date) 
            VALUES ('$name', '$email', '$rating', '$comments', NOW())";

    if ($conn->query($sql) === TRUE) {
        // Set a session variable to indicate success
        $_SESSION['feedback_submitted'] = true;

        // Redirect to success page
        header('Location:feedback_success.php');
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the connection
$conn->close();
?>

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>
    <style>
        /* Global Styling */
        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        #feedback {
            padding: 60px 0;
        }

        #feedback .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            padding: 50px;
            border-radius: 12px;
            box-shadow: 0 6px 30px rgba(0, 0, 0, 0.1);
            border: 1px solid #ddd;
        }

        /* Header Styling */
        #feedback .inner-title {
            text-align: center;
            margin-bottom: 40px;
        }

        #feedback .inner-title h2 {
            font-size: 32px;
            color: #00bfa5;
            font-weight: 700;
            margin-bottom: 10px;
        }

        #feedback .inner-title p {
            font-size: 18px;
            color: #666;
            margin-top: 0;
        }

        /* Form Styling */
        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            font-size: 16px;
            color: #444;
            font-weight: 600;
            display: block;
            margin-bottom: 10px;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            color: #333;
            background-color: #fafafa;
            transition: all 0.3s ease;
        }

        .form-control:hover {
            border-color: #00bfa5;
        }

        .form-control:focus {
            outline: none;
            border-color: #00bfa5;
            box-shadow: 0 0 10px rgba(0, 191, 165, 0.2);
        }

        /* Radio Buttons Styling */
        .radio-inline {
            margin-right: 20px;
            font-size: 15px;
            color: #555;
            position: relative;
            padding-left: 28px;
        }

        .radio-inline input {
            position: absolute;
            top: 0;
            left: 0;
            margin: 0;
            width: 18px;
            height: 18px;
        }

        .radio-inline input:checked + label:before {
            border-color: #00bfa5;
        }

        textarea.form-control {
            resize: none;
            height: 150px;
        }

        /* Button Styling */
        .btn {
            background-color: #00bfa5;
            color: white;
            border: none;
            padding: 15px 20px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            border-radius: 6px;
            width: 100%;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 191, 165, 0.4);
        }

        .btn:hover {
            background-color: #009f89;
            box-shadow: 0 6px 25px rgba(0, 191, 165, 0.6);
        }

        .btn:focus {
            outline: none;
            box-shadow: 0 0 12px rgba(0, 191, 165, 0.6);
        }

        /* Responsive Styling */
        @media (max-width: 768px) {
            .form-group label {
                font-size: 14px;
            }

            #feedback .inner-title h2 {
                font-size: 28px;
            }
        }

    </style>
</head>
<body>

<!-- Feedback Form Section -->
<section id="feedback" class="feedback-form">
    <div class="container">
        <div class="inner-title">
            <h2>Feedback Form</h2>
            <p>We value your feedback. Please share your experience with us!</p>
        </div>
        <form method="post" action="feedback.php"> <!-- Added action -->
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name" required>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label for="rating">Rating (1-5):</label>
                        <label class="radio-inline">
                            <input type="radio" name="rating" value="1" required> 1 - Poor
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="rating" value="2"> 2 - Fair
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="rating" value="3"> 3 - Good
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="rating" value="4"> 4 - Very Good
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="rating" value="5"> 5 - Excellent
                        </label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label for="comments">Comments:</label>
                        <textarea class="form-control" id="comments" name="comments" rows="5" placeholder="Enter your comments here..." required></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-success" name="submitFeedback">Submit Feedback</button>
                </div>
            </div>
        </form>
    </div>
</section>

</body>
</html>

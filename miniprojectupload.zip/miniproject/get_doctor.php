<?php
include('include/config.php');

if (!empty($_POST['specilizationid'])) {
    $specilizationid = $_POST['specilizationid'];
    $query = mysqli_query($con, "SELECT * FROM doctors WHERE specilization = '$specilizationid'");
    echo "<option value=''>Select Doctor</option>";
    while ($row = mysqli_fetch_array($query)) {
        echo "<option value='" . $row['id'] . "'>" . $row['doctorName'] . "</option>";
    }
}

if (!empty($_POST['doctor'])) {
    $doctorid = $_POST['doctor'];
    $query = mysqli_query($con, "SELECT consultancyFees FROM doctors WHERE id = '$id'");
    while ($row = mysqli_fetch_array($query)) {
        echo $row['consultancyFees'];
    }
}
?>

<?php
session_start();
error_reporting(0);
include('include/config.php');
if (strlen($_SESSION['id'] == 0)) {
    header('location:logout.php');
} else {

    if (isset($_GET['viewid'])) {
        $pid = intval($_GET['viewid']);
        $sql = mysqli_query($con, "SELECT * FROM tblpatient WHERE ID='$pid'");
        $row = mysqli_fetch_array($sql);
        if (!$row) {
            echo "<h4 class='text-danger text-center mt-5'>Patient not found!</h4>";
            exit;
        }
    } else {
        echo "<h4 class='text-danger text-center mt-5'>Invalid Request!</h4>";
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Patient Details</title>
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 30px;
            background: #ffffff;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .table th {
            background-color:rgb(46, 111, 129);
            color: white;
        }
        .btn-primary {
            margin-top: 15px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2 class="text-primary">Patient Details</h2>
        <table class="table table-bordered table-striped">
            <tr>
                <th>Patient Name</th>
                <td><?php echo $row['PatientName']; ?></td>
            </tr>
            <tr>
                <th>Contact Number</th>
                <td><?php echo $row['PatientContno']; ?></td>
            </tr>
            <tr>
                <th>Gender</th>
                <td><?php echo $row['PatientGender']; ?></td>
            </tr>
            <tr>
                <th>Address</th>
                <td><?php echo $row['PatientAdd']; ?></td>
            </tr>
            <tr>
                <th>Age</th>
                <td><?php echo $row['PatientAge']; ?></td>
            </tr>
            <tr>
                <th>Medical History</th>
                <td><?php echo $row['PatientMedhis']; ?></td>
            </tr>
            <tr>
                <th>Creation Date</th>
                <td><?php echo $row['CreationDate']; ?></td>
            </tr>
            <tr>
                <th>Last Update</th>
                <td><?php echo $row['UpdationDate']; ?></td>
            </tr>
        </table>
        <div class="text-center">
            <a href="manage-patients.php" class="btn btn-primary">Back to Patients List</a>
        </div>
    </div>
</body>

</html>

<?php } ?>

<?php
// Start session and include necessary files
session_start();
include('include/config.php');
include('include/checklogin.php');
check_login();

// Get the logged-in doctor's ID (assuming doctors are logged in)
$doctorId = $_SESSION['id'];

// Fetch all patients assigned to this doctor
$patientsQuery = mysqli_query($con, "SELECT users.id, users.fullName FROM users
    INNER JOIN doctor_patient ON doctor_patient.patient_id = users.id
    WHERE doctor_patient.doctor_id = '$doctorId'");

$patientId = '';
$journalsQuery = null;

if (isset($_GET['patientId']) && !empty($_GET['patientId'])) {
    $patientId = $_GET['patientId'];

    // Fetch the journal entries for the selected patient
    $journalsQuery = mysqli_query($con, "SELECT * FROM journals WHERE user_id = '$patientId' ORDER BY entry_date");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor | View Patient Journals</title>
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <style>
        /* Add some custom styling */
        body {
            background-color: #f4f7f6;
            font-family: 'Arial', sans-serif;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
        }

        .form-group label {
            font-weight: bold;
            color: #34495e;
        }

        .table {
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .table th {
            background-color: #2c3e50;
            color: white;
        }

        .table tbody tr:nth-child(odd) {
            background-color: #f9f9f9;
        }

        .table tbody tr:nth-child(even) {
            background-color: #ecf0f1;
        }

        .fa {
            margin-right: 5px;
        }

        .btn-primary {
            background-color: #2980b9;
            border-color: #2980b9;
        }

        .btn-primary:hover {
            background-color: #1abc9c;
            border-color: #16a085;
        }

        .container {
            margin-top: 50px;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .no-journal-message {
            text-align: center;
            color: #e74c3c;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mt-4">Patient Journals</h2>

        <!-- Patient selection dropdown -->
        <form method="GET">
            <div class="form-group">
                <label for="patientId">Select Patient:</label>
                <select class="form-control" name="patientId" id="patientId" required>
                    <option value="">Choose a patient</option>
                    <?php
                    while ($row = mysqli_fetch_array($patientsQuery)) {
                        $selected = ($row['id'] == $patientId) ? 'selected' : '';  // Retain selected patient
                        echo "<option value='" . $row['id'] . "' $selected>" . $row['fullName'] . "</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">View Journals</button>
        </form>

        <!-- Display journal entries if a patient is selected -->
        <?php if ($journalsQuery && mysqli_num_rows($journalsQuery) > 0) { ?>
            <h3 class="mt-5">Journal History</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Mood</th>
                        <th>Activities</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($journal = mysqli_fetch_array($journalsQuery)) {
                        echo "<tr>";
                        echo "<td>" . $journal['entry_date'] . "</td>";
                        echo "<td>";
                        switch ($journal['mood']) {
                            case 1: echo "<i class='fa fa-frown-o' style='font-size: 24px;'></i> Very Sad"; break;
                            case 2: echo "<i class='fa fa-meh-o' style='font-size: 24px;'></i> Sad"; break;
                            case 3: echo "<i class='fa fa-meh-o' style='font-size: 24px;'></i> Neutral"; break;
                            case 4: echo "<i class='fa fa-smile-o' style='font-size: 24px;'></i> Happy"; break;
                            case 5: echo "<i class='fa fa-smile-o' style='font-size: 24px;'></i> Very Happy"; break;
                        }
                        echo "</td>";
                        echo "<td>" . $journal['activities'] . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        <?php } elseif (!empty($patientId)) { ?>
            <p class="no-journal-message">No journal entries found for this patient.</p>
        <?php } ?>
    </div>
</body>
</html>

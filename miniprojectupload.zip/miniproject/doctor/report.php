<?php
session_start();
error_reporting(0);
include('include/config.php');

// Initialize variables
$patient_id = isset($_GET['patient_id']) ? $_GET['patient_id'] : null;
$patient = null;
$consultation_result = null;

if ($patient_id) {
    // Fetch patient details
    $patient_sql = "SELECT * FROM tblpatient WHERE ID = $patient_id";
    $patient_result = mysqli_query($con, $patient_sql);
    $patient = mysqli_fetch_assoc($patient_result);

    // Fetch consultation history
    $consultation_sql = "
        SELECT consultations.*, Doctors.doctorName, Doctors.specilization, Doctors.docFees 
        FROM consultations 
        JOIN Doctors ON consultations.doctor_id = Doctors.id
        WHERE consultations.patient_id = $patient_id
        ORDER BY consultations.date_of_consultation";
    $consultation_result = mysqli_query($con, $consultation_sql);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Patient Report</title>
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <style>
        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .report-table th, .report-table td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        .report-table th {
            background-color: #f2f2f2;
            text-align: left;
        }
        .header {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="header">Patient Report</h2>

    <!-- Patient ID Form -->
    <form method="GET" action="report.php">
        <div class="form-group">
            <label for="patient_id">Enter Patient ID:</label>
            <input type="text" class="form-control" name="patient_id" id="patient_id" required>
        </div>
        <button type="submit" class="btn btn-primary">Generate Report</button>
    </form>

    <?php if ($patient): ?>
        <!-- Patient Information -->
        <h3>Patient Information</h3>
        <table class="report-table">
            <tr><th>Patient Name</th><td><?php echo $patient['PatientName']; ?></td></tr>
            <tr><th>Contact Number</th><td><?php echo $patient['PatientContno']; ?></td></tr>
            <tr><th>Email</th><td><?php echo $patient['PatientEmail']; ?></td></tr>
            <tr><th>Gender</th><td><?php echo $patient['PatientGender']; ?></td></tr>
            <tr><th>Address</th><td><?php echo $patient['PatientAdd']; ?></td></tr>
            <tr><th>Age</th><td><?php echo $patient['PatientAge']; ?></td></tr>
            <tr><th>Medical History</th><td><?php echo $patient['PatientMedhis']; ?></td></tr>
            <tr><th>Creation Date</th><td><?php echo $patient['CreationDate']; ?></td></tr>
            <tr><th>Last Update</th><td><?php echo $patient['UpdationDate']; ?></td></tr>
        </table>

        <!-- Consultation History -->
        <h3>Consultation History</h3>
        <table class="report-table">
            <thead>
                <tr>
                    <th>Date of Consultation</th>
                    <th>Doctor Name</th>
                    <th>Specialization</th>
                    <th>Consultation Fees</th>
                    <th>Diagnosis</th>
                    <th>Prescription</th>
                    <th>Follow-up Date</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($consultation = mysqli_fetch_assoc($consultation_result)) { ?>
                <tr>
                    <td><?php echo $consultation['date_of_consultation']; ?></td>
                    <td><?php echo $consultation['doctorName']; ?></td>
                    <td><?php echo $consultation['specilization']; ?></td>
                    <td><?php echo $consultation['docFees']; ?></td>
                    <td><?php echo $consultation['diagnosis']; ?></td>
                    <td><?php echo $consultation['prescription']; ?></td>
                    <td><?php echo $consultation['follow_up_date']; ?></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    <?php elseif ($_SERVER['REQUEST_METHOD'] == 'GET' && $patient_id): ?>
        <p>No patient found with ID <?php echo htmlspecialchars($patient_id); ?>.</p>
    <?php endif; ?>
</div>

</body>
</html>

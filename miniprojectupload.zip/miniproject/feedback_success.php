<?php
session_start(); // Start the session to retrieve feedback message

// Check if feedback was submitted
if (!isset($_SESSION['feedback_submitted'])) {
    header('Location: submit_feedback.php'); // Redirect to feedback form if accessed directly
    exit();
}

// Clear the session variable
unset($_SESSION['feedback_submitted']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Submitted</title>
    <style>
        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
        }

        .message-container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            color: #00bfa5;
        }

        .btn {
            background-color: #00bfa5;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 6px;
            text-decoration: none;
            margin-top: 20px;
            display: inline-block;
        }

        .btn:hover {
            background-color: #009f89;
        }
    </style>
</head>
<body>

<div class="message-container">
    <h2>Feedback Submitted Successfully!</h2>
    <p>Thank you for your feedback. We appreciate your input!</p>
    <a href="index.php" class="btn">Go Back to Home</a> <!-- Adjust the link to your homepage -->
</div>

</body>
</html>

 
 <?php
session_start();
include('include/config.php');
include('include/checklogin.php');
check_login();

if (isset($_POST['submitJournal'])) {
    $userId = $_SESSION['id'];  // Logged-in user's ID
    $mood = $_POST['mood'];     // Mood value from form
    $activities = $_POST['activities'];  // Journal text from form
    $entryDate = date('Y-m-d');  // Current date

    // Insert into the database
    $query = mysqli_query($con, "INSERT INTO journals (user_id, mood, activities, entry_date) VALUES ('$userId', '$mood', '$activities', '$entryDate')");

    if ($query) {
        $_SESSION['msg'] = "Journal entry added successfully!";
    } else {
        $_SESSION['msg'] = "Error adding journal entry!";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Journal and Mood Tracking</title>
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
</head>
</body><!-- Journal History -->
 <h3 class="mt-5">Journal History</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Mood</th>
                    <th>Activities</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $userId = $_SESSION['id'];  // Logged-in user's ID
            $historyQuery = mysqli_query($con, "SELECT * FROM journals WHERE user_id='$userId' ORDER BY entry_date DESC");
            if (mysqli_num_rows($historyQuery) > 0) {
                while ($row = mysqli_fetch_array($historyQuery)) {
                    echo "<tr>";
                    echo "<td>" . $row['entry_date'] . "</td>";
                    echo "<td>";
                    switch ($row['mood']) {
                        case 1: echo "<i class='fa fa-frown-o' style='font-size: 24px;'></i> Very Sad"; break;
                        case 2: echo "<i class='fa fa-meh-o' style='font-size: 24px;'></i> Sad"; break;
                        case 3: echo "<i class='fa fa-meh-o' style='font-size: 24px;'></i> Neutral"; break;
                        case 4: echo "<i class='fa fa-smile-o' style='font-size: 24px;'></i> Happy"; break;
                        case 5: echo "<i class='fa fa-smile-o' style='font-size: 24px;'></i> Very Happy"; break;
                    }
                    echo "</td>";
                    echo "<td>" . $row['activities'] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No journal entries found.</td></tr>";
            }
            ?>
            </tbody>
        </table>
    </div>
</body>
</html>
